
<?php
session_start();
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Material Design Bootstrap</title>
        <!-- Font Awesome -->
        <!-- <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css"> -->
        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <!-- Material Design Bootstrap -->
        <link href="css/mdb.min.css" rel="stylesheet">
        <!-- Your custom styles (optional) -->
        <link href="css/style.css" rel="stylesheet">
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- Custom fonts for this template -->
        <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="css/grayscale.min.css" rel="stylesheet">

    </head>
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand js-scroll-trigger" href="#page-top">Clerance Request</a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="home.html">HOME</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="About.html">ABOUT</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="setting.html">SETTING</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <head>
        <title>Request</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>

    <!-- Material form contact -->
    <div class="card">

        <h5 class="card-header info-color white-text text-center py-4">

        </h5>
        <form action="../model/create.php" method="post">
            <!--Card content-->
            <div class="card-body px-lg-5 pt-0">

                <!-- Form -->
                <form class="text-center" style="color: #757575;">
                    <h2>Choose Date</h2>
                    <div class="md-form col-md-5" >
                        <input name="Last_class_date" type="date" id="inputMDEx" class="form-control">
                        <label for="inputMDEx">Choose your date</label>
                    </div>
                    <h2>Reason</h2>
                    <!-- Message -->
                    <div class="form-group col-md-5">
                        <textarea class="form-control rounded-0" id="exampleFormControlTextarea2" rows="3" id="message" placeholder="Message" name="message"></textarea>
                    </div>

                    <!-- Copy -->
                    <div class="custom-control custom-checkbox col-md-5">
                        <!--<input name="message" type="checkbox" class="custom-control-input" id="defaultContactFormCopy">-->
                        <label class="custom-control-label" for="defaultContactFormCopy">Send me a copy of this message</label>


                        <!-- Default unchecked -->

                        <div class="custom-control custom-radio  col-md-2">
                            <input  type="radio" class="custom-control-input" id="defaultUnchecked" name="type" value="withdrwal" checked>
                            <label class="custom-control-label" for="defaultUnchecked">Withdrwal</label>
                        </div>

                        <!-- Default checked -->
                        <div class="custom-control custom-radio  col-md-2" >
                            <input  type="radio" class="custom-control-input" id="defaultChecked" name="type" value="graduate"  checked>
                            <label class="custom-control-label" >Graduated</label>
                        </div>

                        <div class="custom-control custom-radio  col-md-2" >
                            <input  type="radio" class="custom-control-input" id="defaultChecked" name="type" value="Dismisal" checked>
                            <label class="custom-control-label" >Dismisal</label>
                        </div>


                        <!-- Subject -->


                        <!-- Default checked -->


                        <!-- Copy -->

                        <!-- Send button -->
                        <button class="btn btn-outline-info btn-rounded btn-block z-depth-0 my-4 waves-effect " type="submit">Send Request</button>


                </form>
                <!-- Form -->
                <?php
//                if (isset($_SESSION["reqerror"]) || isset($_SESSION["reqsuccess"])) {
                        $div = "<div class='alert'>";
                    if (isset($_SESSION["reqerror"])) {
                        $div1 = $div."<div class='alert alert-danger'>".$_SESSION["reqerror"];
                    }  else {
                        $div1 = $div."<div class='alert alert-success'>".$_SESSION["reqsuccess"];
                    }
                    echo $div1 . "</div></div>";
//                }
                ?>
        </form>
    </div>

    <div class="social d-flex justify-content-center">


    </div>

</div>
</section>

<!-- Footer -->
<footer class="bg-black small text-center text-white-50">
    <div class="container">
        Copyright &copy; Your Website 2019
    </div>
</footer>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Plugin JavaScript -->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for this template -->
<script src="js/grayscale.min.js"></script>


<!-- SCRIPTS -->
<!-- JQuery -->
<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="js/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="js/mdb.min.js"></script>


</body>
</html>
