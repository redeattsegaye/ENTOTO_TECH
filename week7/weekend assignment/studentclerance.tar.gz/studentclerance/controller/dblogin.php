<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of dblogin
 *
 * @author mis hacker
 */
class dblogin {

    private $conn;

    function __construct() {
        include_once '../controller/dbconnect.php';
        $db = new dbconnect();
        $this->conn = $db->connect();
    }

    public function userlogin($user, $pass) {
        $stm = $this->conn->prepare("select * from student where username=? and password=?");
        $stm->bind_param("ss", $user, $pass);
        $stm->execute();
        $stm->store_result();
        if ($stm->num_rows > 0) {
            return 1;
        } else {
            return 2;
        }
    }

    public function officelogin($user, $pass) {
        $stm = $this->conn->prepare("select * from office where officername=? and password=?");
        $stm->bind_param("ss", $user, $pass);
        $stm->execute();
        $stm->store_result();
        if ($stm->num_rows > 0) {
            return 1;
        } else {
            return 2;
        }
    }

    public function getofficetype($user) {
        $stm = $this->conn->prepare("select * from office where officername=?");
        $stm->bind_param("s", $user);
        $stm->execute();
        return $stm->get_result()->fetch_assoc();
    }

    public function getstudent($user) {
        $stm = $this->conn->prepare("select * from student where username=?");
        $stm->bind_param("s", $user);
        $stm->execute();
        return $stm->get_result()->fetch_assoc();
    }

    public function request($Last_date, $type, $message,$studentid) {
        $stm = $this->conn->prepare("insert into request(Last_class_date,type, message,student_id)values(?,?,?,?);");
        $stm->bind_param("sssi", $Last_date, $type, $message, $studentid);
        if ($stm->execute()) {
            return 1;
        } else {
            return 2;
        }
    }

    public function updatepass($user, $newpass) {
        $stm = $this->conn->prepare("update login set password=? where username=? ");
        $stm->bind_param("ss", $newpass, $user);
        if ($stm->execute()) {
            return 1;
        } else {
            return 2;
        }
    }

    public function getprivilage($username) {
        $stm = $this->conn->prepare("select * from login where username=?");
        $stm->bind_param("s", $username);
        $stm->execute();
        return $stm->get_result()->fetch_assoc;
    }

    public function signup($fullname, $age, $gender, $department, $program, $registration_date, $username, $password, $student_id, $phone) {
        $stm = $this->conn->prepare("insert into student(fullname,age,gender,department,program,registration_date,username,password,student_id,phone)values(?,?,?,?,?,?,?,?,?,?);");
        $stm->bind_param("ssssssssss", $fullname, $age, $gender, $department, $program, $registration_date, $username, $password, $student_id, $phone);
        if ($stm->execute()) {
            return 1;
        } else {
            return 2;
        }
    }

}
