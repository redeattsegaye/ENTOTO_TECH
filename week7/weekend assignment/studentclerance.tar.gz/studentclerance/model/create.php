<?php
include_once '../controller/dblogin.php';
session_start();
if( isset($_POST['Last_class_date'])and isset($_POST['type'])and isset($_POST['message'])){
    
    
   

  $Last_class_date = $_POST['Last_class_date'];
  $type = $_POST['type'];
  $message = $_POST['message'];
  $user = $_SESSION["username"];

  
//  
   $db=new dblogin();
   
   $student = $db->getstudent($user);
   $studentid = $student["student_id"];
   $result=$db->request($Last_class_date,$type,$message, $studentid);
   if($result =='1'){
//       echo 'sucessfuly sent';
       $_SESSION["reqsuccess"] = "success fully sent";
        header("Location: ../MDB-Free_4.8.2/request.php");
       }  else {
       $_SESSION["reqerror"] = "req error";
         header("Location: ../MDB-Free_4.8.2/request.php");
       }
//       
       
} 
      
    



