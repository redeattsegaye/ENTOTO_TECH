<?php
 include_once '../controller/dblogin.php';

if(isset($_POST['user']) && isset($_POST['newpass'])){
  $user=$_POST['user']; 
 
   $newpass=$_POST['newpass'];
   echo $user;
  
   $db=new dblogin();
   $result=$db->updatepass($user,$newpass);
   
       if($result =='1'){
       //secho 'sucessfuly login';
       header("Location: ../view/phptest.php");
     // window.open("../MDB-Free_4.8.2/index.php");
       }
       else {
//         
           
 header("Location: ../MDB-Free_4.8.2/invalid.html");

                  
       }
    

}



/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

