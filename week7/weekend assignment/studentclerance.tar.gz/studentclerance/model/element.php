<?php

include_once '../controller/dbconnect.php';




function getelements() {
        
    $db = new dbconnect();
    $conn = $db->connect();

    $stm =$conn->query("SELECT * FROM student,request WHERE request.student_id = student.student_id");
    return $stm;
}

function getelementsreg() {
        
    $db = new dbconnect();
    $conn = $db->connect();

    $stm =$conn->query("SELECT * FROM student,request,status WHERE request.student_id = student.student_id and request.reqid = status.Reqid");
    return $stm;
}


function getstatusStud($requester) {
       
    $db = new dbconnect();
    $conn = $db->connect();

    $stm = $conn->prepare("SELECT * FROM request,status,student WHERE status.Reqid = request.reqid AND student.student_id = request.student_id AND student.username = ?");
    $stm->bind_param("s", $requester);
    $stm->execute();
    return $stm->get_result()->fetch_assoc();
}

function getstatus($reqid) {
       
    $db = new dbconnect();
    $conn = $db->connect();

    $stm = $conn->prepare("SELECT * FROM status,office WHERE office.id = status.officeid AND status.Reqid = ?");
    $stm->bind_param("s", $reqid);
    $stm->execute();
    return $stm->get_result()->fetch_assoc();
}
?>
