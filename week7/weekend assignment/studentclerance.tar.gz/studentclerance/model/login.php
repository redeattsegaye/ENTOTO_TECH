<?php
 include_once '../controller/dblogin.php';
 session_start();
if(isset($_POST['user'])and isset($_POST['pass'])){
  $user=$_POST['user']; 
   $pass=$_POST['pass'];
   
   echo $user;
   echo $pass;
   $db=new dblogin();
   $result=$db->userlogin($user,$pass);
   if($result =='1'){
   $alluser=$db->getprivilage($user);
       $privilage=$alluser['privilage'];
       $_SESSION['privilage']=$privilage;
       
       
//       echo '<script> window.location.href="../view/.php"</script>';
       $_SESSION["username"] = $user;
       header("Location: ../MDB-Free_4.8.2/home.html");
       }
       else if ($user== " " && $pass==" "){
           echo 'Empty field';
       }
       
       
       else{
          header("Location: ../MDB-Free_4.8.2/invalidpass.html");
           
       }
       
}


