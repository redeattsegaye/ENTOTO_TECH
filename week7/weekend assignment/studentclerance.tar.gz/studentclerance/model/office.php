<?php

echo "test";
include_once '../controller/dblogin.php';
session_start();
if (isset($_POST['user'])and isset($_POST['pass']) || !empty($_POST["user"]) || !empty($_POST["pass"])) {
    $user = $_POST['user'];
    $pass = $_POST['pass'];

    $db = new dblogin();
    $result = $db->officelogin($user, $pass);
    if ($result =='1') {
//        header("Location: /studentclerance/view/libraryhome.html");
        $type = $db->getofficetype($user);
        $_SESSION["officeid"] = $type["id"];
        $_SESSION["officetype"] = $type["officename"];
        if($type["officename"] == "library"){
            header("Location: ../../view/libraryhome.html");
        }else if($type["officename"] == "Registrar") {
            header("Location: ../../view/newhome.html");
        }
    } else {
        $_SESSION["error"] = "Incorect Username or Password";
        header("Location: ../../view/officelogin.php");
    }
} 
if (!isset($_POST["user"]) || $_POST["user"] == "") {
    $_SESSION["error"] = "provide Username";
    header("Location: ../../view/officelogin.php");
} else if (!isset($_POST["pass"]) || $_POST["pass"] == "") {
    $_SESSION["error"] = "provide password";
    header("Location: ../../view/officelogin.php");
} else {
    
}
?>

