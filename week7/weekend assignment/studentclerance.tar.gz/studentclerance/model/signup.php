<?php
 include_once '../controller/dblogin.php';

if(isset($_POST['fullname'])and isset($_POST['age'])and isset($_POST['gender'])and isset($_POST['department'])and isset($_POST['program'])and isset($_POST['registration_date'])and isset($_POST['username'])and isset($_POST['password'])and isset($_POST['student_id'])and isset($_POST['phone'])){
  $fullname=$_POST['fullname'];
 $age=$_POST['age'];
  $gender=$_POST['gender'];
  $department=$_POST['department'];
  $program=$_POST['program'];
  $registration_date=$_POST['registration_date'];
  $student_id=$_POST['student_id'];
  $username=$_POST['username'];
  $password=$_POST['password'];
  $phone=$_POST['phone'];
  
  $db=new dblogin();
   $result=$db->signup($fullname,$age,$gender,$department,$program,$registration_date,$username,$password,$student_id,$phone);
   if($result =='1'){
      
       header("Location: ../view/phptest.php");
       }
       
       
      else{
          echo 'error'; 
           
      }
       
} 


