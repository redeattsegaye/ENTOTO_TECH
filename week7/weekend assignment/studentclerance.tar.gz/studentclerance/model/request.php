<?php
session_start();
include_once '../controller/dbconnect.php';
$db = new dbconnect();
$conn = $db->connect();


$officer = $_SESSION["officeid"];
$officetype = $_SESSION["officetype"];
echo "l".$officetype;
if($officetype == "library" && isset($_GET["id"])){

    $id = $_GET["id"];
    $stm =$conn->query("SELECT * FROM status WHERE status.Reqid = $id ");
    $stm =  $stm->fetch_assoc();

    echo $stm["Reqid"];
   

if ($_GET["type"] == "accept" && $stm["Reqid"] == "") {
    $stat = 1;
    $stm = $conn->prepare("insert into status(Reqid ,officeid ,status )values(?,?,?);");
    $stm->bind_param("ssi", $id, $officer, $stat);
    if ($stm->execute()) {
        // return 1;
    } else {
        // return 2;
    }
    header("Location: ../view/element.php");
    

}else if($_GET["type"] == "decline" && $stm["Reqid"] == ""){
    $stat = -1;
    $stm = $conn->prepare("insert into status(Reqid ,officeid ,status )values(?,?,?);");
    $stm->bind_param("ssi", $id, $officer, $stat);
    if ($stm->execute()) {
        // return 1;
    } else {
        // return 2;
    }
    header("Location: ../view/element.php");
}
else{
    header("Location: ../view/element.php");
}
}


if($officetype == "Registrar" && isset($_GET["id"])){

    $id = $_GET["id"];
    $stm =$conn->query("SELECT * FROM status WHERE status.Reqid = $id ");
    $stm =  $stm->fetch_assoc();

    echo $stm["Reqid"];
   

if ($_GET["type"] == "accept" && $stm["status"] > 0) {
    $stat = 2;
    $stm = $conn->prepare("UPDATE status SET officeid = ?,status = ? WHERE status.Reqid = ?;");
    $stm->bind_param("sii", $officer, $stat , $id);
    if ($stm->execute()) {
        // return 1;
    } else {
        // return 2;
    }
    header("Location: ../../view/reghome.php");
    

}else if($_GET["type"] == "decline" && $stm["status"] > 0){
    $stat = -2;
    $stm = $conn->prepare("UPDATE status SET officeid = ?,status = ? WHERE status.Reqid = ?;");
    $stm->bind_param("sii", $officer, $stat,$id);
    if ($stm->execute()) {
        // return 1;
    } else {
        // return 2;
    }
    header("Location: ../../view/reghome.php");}
else{
    header("Location: ../../view/reghome.php");}
}


?>