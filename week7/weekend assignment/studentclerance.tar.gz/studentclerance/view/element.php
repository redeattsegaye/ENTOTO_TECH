 <?php
 
 	session_start();
 
    //    include_once '../controller/dbconnect.php';
//        $db=new dbconnect();
//        $conn=$db->connect();
//        //$query="select * from request";//to fetch data
//        $query="SELECT *
// FROM student
// INNER JOIN request
// ON request.student_id=student.student_id";
//        $result=mySqli_query($conn,$query);//database files
//        if($result){
//           //  echo 'error'.  mysqli_error($conn);
//        }
       
       
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Request Status</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Course Project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="styles/elements_styles.css">
<link rel="stylesheet" type="text/css" href="styles/elements_responsive.css">
</head>
<body>
	<script>
var dataSet = [
["Tiger Nixon", "System Architect", "Edinburgh", "5421", "2011-04-25", "$320,800"],
["Garrett Winters", "Accountant", "Tokyo", "8422", "2011-07-25", "$170,750"],
["Ashton Third Cox", "Junior Technical Author", "San Francisco", "1562", "2009-01-12", "$86,000"],
["Cedric Kelly", "Senior Javascript Developer", "Edinburgh", "6224", "2012-03-29", "$433,060"],
["Airi", "Accountant", "Tokyo", "5407", "2008-11-28", "$162,700"],
["Brielle Williamson Need More Space To Check It", "Integration Specialist", "New York", "4804", "2012-12-02",
"$372,000"
],
["Herrod Chandler", "Sales Assistant", "San Francisco", "9608", "2012-08-06", "$137,500"],
["Rhona Davidson", "Integration Specialist", "Tokyo", "6200", "2010-10-14", "$327,900"],
["Colleen Hurst", "Javascript Developer", "San Francisco", "2360", "2009-09-15", "$205,500"],
["Sonya Frost", "Software Engineer", "Edinburgh", "1667", "2008-12-13", "$103,600"],
["Jena Gaines", "Office Manager", "London", "3814", "2008-12-19", "$90,560"],
["Quinn Flynn", "Support Lead", "Edinburgh", "9497", "2013-03-03", "$342,000"],
["Charde Marshall", "Regional Director", "San Francisco", "6741", "2008-10-16", "$470,600"],
["Haley Kennedy", "Senior Marketing Designer", "London", "3597", "2012-12-18", "$313,500"],
["Tatyana Fitzpatrick", "Regional Director", "London", "1965", "2010-03-17", "$385,750"],
["Michael Silva", "Marketing Designer", "London", "1581", "2012-11-27", "$198,500"],
["Paul Byrd", "Chief Financial Officer (CFO)", "New York", "3059", "2010-06-09", "$725,000"],
["Gloria Little", "Systems Administrator", "New York", "1721", "2009-04-10", "$237,500"],
["Bradley Fourth Fourth Greer", "Software Engineer", "London", "2558", "2012-10-13", "$132,000"],
["Dai Rios", "Personnel Lead", "Edinburgh", "2290", "2012-09-26", "$217,500"],
["Jenette Caldwell", "Development Lead", "New York", "1937", "2011-09-03", "$345,000"],
["Yuri Berry", "Chief Marketing Officer (CMO)", "New York", "6154", "2009-06-25", "$675,000"],
["Caesar Vance", "Pre-Sales Support", "New York", "8330", "2011-12-12", "$106,450"],
["Doris Wilder", "Sales Assistant", "Sidney", "3023", "2010-09-20", "$85,600"],
["Angelica Ramos", "Chief Executive Officer (CEO)", "London", "5797", "2009-10-09", "$1,200,000"],
["Gavin Joyce", "Developer", "Edinburgh", "8822", "2010-12-22", "$92,575"],
["Jennifer Chang", "Regional Director", "Singapore", "9239", "2010-11-14", "$357,650"],
["Brenden Fifth Example Some Wagner", "Software Engineer", "San Francisco", "1314", "2011-06-07", "$206,850"],
["Fiona Green", "Chief Operating Officer (COO)", "San Francisco", "2947", "2010-03-11", "$850,000"],
["Shou Itou", "Regional Marketing", "Tokyo", "8899", "2011-08-14", "$163,000"],
["Michelle House", "Integration Specialist", "Sidney", "2769", "2011-06-02", "$95,400"],
["Suki Burks", "Developer", "London", "6832", "2009-10-22", "$114,500"],
["Prescott Bartlett", "Technical Author", "London", "3606", "2011-05-07", "$145,000"],
["Gavin Cortez", "Team Leader", "San Francisco", "2860", "2008-10-26", "$235,500"],
["Martena Mccray", "Post-Sales support", "Edinburgh", "8240", "2011-03-09", "$324,050"],
["Unity Butler", "Marketing Designer", "San Francisco", "5384", "2009-12-09", "$85,675"]
];

$(document).ready(function () {
var table = $('#dt-select').DataTable({
data: dataSet,
columns: [{
title: "Name"
},
{
title: "Position"
},
{
title: "Office"
},
{
title: "Extn."
},
{
title: "Start date"
},
{
title: "Salary"
}
],

dom: 'Bfrtip',
select: true,
buttons: [{
text: 'Select all',
action: function () {
table.rows().select();
}
},
{
text: 'Select none',
action: function () {
table.rows().deselect();
}
}
]
});
});


		</script>

<div class="super_container">

	<!-- Header -->

	<header class="header d-flex flex-row">
		<div class="header_content d-flex flex-row align-items-center">
			<!-- Logo -->
			<div class="logo_container">
				<div class="logo">
                                    <img src="images/download.jpg" height="100px" alt="">
					<span>OCS</span>
				</div>
			</div>

			<!-- Main Navigation -->
			<nav class="main_nav_container">
				<div class="main_nav">
					<ul class="main_nav_list">
						<li class="main_nav_item"><a href="libraryhome.html">home</a></li>
						<li class="main_nav_item"><a href="element.php">Request Stataus</a></li>
						
						
					</ul>
				</div>
			</nav>
		</div>
		<div class="header_side d-flex flex-row justify-content-center align-items-center">
			<img src="images/phone-call.svg" alt="">
			<span>+251111239720</span>
		</div>

		<!-- Hamburger -->
		<div class="hamburger_container">
			<i class="fas fa-bars trans_200"></i>
		</div>

	</header>
	
	<!-- Menu -->
	<div class="menu_container menu_mm">

		<!-- Menu Close Button -->
		<div class="menu_close_container">
			<div class="menu_close"></div>
		</div>

		<!-- Menu Items -->
		<div class="menu_inner menu_mm">
			<div class="menu menu_mm">
				<ul class="menu_list menu_mm">
					<li class="menu_item menu_mm"><a href="libraryhome.html">Home</a></li>
					<li class="menu_item menu_mm"><a href="elements.html">Request Statuss</a></li>
					
					
				</ul>

				<!-- Menu Social -->
				
				<div class="menu_social_container menu_mm">
					<ul class="menu_social menu_mm">
						
						<li class="menu_social_item menu_mm"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
						
						
					</ul>
				</div>

				<div class="menu_copyright menu_mm"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
			</div>

		</div>

	</div>
	
	<!-- Home -->

	<div class="home">
		<div class="home_background_container prlx_parent">
			<div class="home_background prlx" style="background-image:url(images/contact_background.jpg)"></div>
		</div>
		<div class="home_content">
			<h1>Request Status</h1>
		</div>
	</div>
	<div>
	<table id="dt-select" class="table table-striped table-bordered" cellspacing="0" width="100%">
											<thead>
											  <tr>
												<th>Student Name</th>
												<th>Phone Number</th>
												<th>Gender</th>
												<th>Program</th>
												<th>Request type </th>
												<th>Request date </th>
												<th>student ID  </th>
												<th>Last Approved by </th>
												<th>Action </th>
											  </tr>
											</thead>
											<tfoot>
											 

											<?php 
				  include_once '../model/element.php';


                  $elements = "";
				  if ($_SESSION["officetype"] == "library") {
					$elements = getelements();
				  }else {
					$elements = getelementsreg();
				  }
				  while ($row = $elements->fetch_assoc()) {
					  echo "<tr>";

					  echo "<td>".$row["fullname"]."</td>";
					  echo "<td>".$row["phone"]."</td>";
					  echo "<td>".$row["gender"]."</td>";
					  echo "<td>".$row["program"]."</td>";
					  echo "<td>".$row["type"]."</td>";
					  echo "<td>".$row["reqdate"]."</td>";
					  echo "<td>".$row["student_id"]."</td>";

					  $status = getstatus($row["reqid"]);
					  $buttons = "";
					  if(empty($status["officeid"])){
						echo "<td>None yet</td>";
					  }else{
						  $val = "Accepted by ";
						  if ($status["status"] < 0) {
							  $val = "Rejected By ";
							  $buttons = "disabled";
						  }
						  if($status["status"] > 1){
							$buttons = "disabled";
						  }
					  echo "<td>".$val.$status["officename"]."</td>";
					  		
					  }

					  $accepturl = "onclick='window.location=".'"../model/request.php?type=accept&id='.$row["reqid"].'"'."'";
					  $declineurl = "onclick='window.location=".'"../model/request.php?type=decline&id='.$row["reqid"].'"'."'";
					  echo '<td><button '.$buttons." ".$accepturl.' type="button" class="btn btn-outline-success btn-rounded waves-effect">Accept</button> &nbsp; 

					  <button type="button" '.$buttons." ".$declineurl.'class="btn btn-outline-danger btn-rounded waves-effect">Reject</button></td>';



					  echo "</tr>";
				  }
                  
                  ?>
											</tfoot>
										  </table>
	  </div>
	  


	

				

		
		<!-- Loaders -->

		<div class="loaders">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="elements_title">Loaders</div>
					</div>
				</div>

				<div class="row elements_loaders_container">
					<div class="col-lg-3 loader_col">
						<!-- Loader -->
						<div class="loader" data-perc="0.75"></div>
						<div class="loader_text text-center">students clerance progress</div>
						<div class="loader_sub text-center">In library satus.</div>
					</div>
					<div class="col-lg-3 loader_col">
						<!-- Loader -->
						<div class="loader" data-perc="0.83"></div>
						<div class="loader_text text-center">from yera to year</div>
						<div class="loader_sub text-center">Avarager</div>
						<span></span>
					</div>
					<div class="col-lg-3 loader_col">
						<!-- Loader -->
						<div class="loader" data-perc="0.25"></div>
						<div class="loader_text text-center">Development status</div>
						<div class="loader_sub text-center">our library sysytam</div>
					</div>
					<div class="col-lg-3 loader_col">
						<!-- Loader -->
						<div class="loader" data-perc="0.95"></div>
						<div class="loader_text text-center">our books </div>
						<div class="loader_sub text-center">it increase the level of education</div>
					</div>
				</div>

			</div>
		</div>
		
		<!-- Milestones -->
		
		<div class="milestones">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="elements_title">Status</div>
					</div>
				</div>
			</div>

			<div class="milestones_container">
				<div class="milestones_background" style="background-image:url(images/milestones_background.jpg)"></div>
				
				<div class="container">
					<div class="row">
						
						<!-- Milestone -->
						<div class="col-lg-3 milestone_col">
							<div class="milestone text-center">
								<div class="milestone_icon"><img src="images/milestone_1.svg" alt="https://www.flaticon.com/authors/zlatko-najdenovski"></div>
								<div class="milestone_counter" data-end-value="750">0</div>
								<div class="milestone_text">Current Students</div>
							</div>
						</div>

						<!-- Milestone -->
						<div class="col-lg-3 milestone_col">
							<div class="milestone text-center">
								<div class="milestone_icon"><img src="images/milestone_2.svg" alt="https://www.flaticon.com/authors/zlatko-najdenovski"></div>
								<div class="milestone_counter" data-end-value="120">0</div>
								<div class="milestone_text">Certified Teachers</div>
							</div>
						</div>

						<!-- Milestone -->
						<div class="col-lg-3 milestone_col">
							<div class="milestone text-center">
								<div class="milestone_icon"><img src="images/milestone_3.svg" alt="https://www.flaticon.com/authors/zlatko-najdenovski"></div>
								<div class="milestone_counter" data-end-value="39">0</div>
								<div class="milestone_text">Approved Courses</div>
							</div>
						</div>

						<!-- Milestone -->
						<div class="col-lg-3 milestone_col">
							<div class="milestone text-center">
								<div class="milestone_icon"><img src="images/milestone_4.svg" alt="https://www.flaticon.com/authors/zlatko-najdenovski"></div>
								<div class="milestone_counter" data-end-value="3500" data-sign-before="+">0</div>
								<div class="milestone_text">Graduate Students</div>
							</div>
						</div>

					</div>
				</div>
			</div>

		</div>

		<!-- Icon Boxes -->

		<div class="icon_boxes">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="elements_title">our service</div>
					</div>
				</div>

				<div class="row icon_boxes_container">

					<div class="col-lg-4 icon_box text-left d-flex flex-column align-items-start justify-content-start">
						<div class="icon_container d-flex flex-column justify-content-end">
							<img src="images/earth-globe.svg" alt="">
						</div>
						<h3>Online Courses</h3>
						<p>This is so simple and amazing oportinties i llove that.This is so simple and amazing oportinties i llove that</p>
					</div>

					<div class="col-lg-4 icon_box text-left d-flex flex-column align-items-start justify-content-start">
						<div class="icon_container d-flex flex-column justify-content-end">
							<img src="images/exam.svg" alt="">
						</div>
						<h3>Indoor Courses</h3>
						<p>This is so simple and amazing oportinties i llove that.This is so simple and amazing oportinties i llove that</p>
					</div>

					<div class="col-lg-4 icon_box text-left d-flex flex-column align-items-start justify-content-start">
						<div class="icon_container d-flex flex-column justify-content-end">
							<img src="images/books.svg" alt="">
						</div>
						<h3>Amazing Library</h3>
						<p>This is so simple and amazing oportinties i llove that.This is so simple and amazing oportinties i llove that.</p>
					</div>

				</div>

			</div>
		</div>

	</div>

	<!-- Footer -->

	<footer class="footer">
		<div class="container">
			
			<!-- Footer Copyright -->

			<div class="footer_bar d-flex flex-column flex-sm-row align-items-center">
				<div class="footer_copyright">
					<span>AAit All rights reserved</span>
				</div>
				<div class="footer_social ml-sm-auto">
					<ul class="menu_social">
						
						<li class="menu_social_item"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
						
					</ul>
				</div>
			</div>

		</div>
	</footer>

</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/progressbar/progressbar.min.js"></script>
<script src="plugins/scrollTo/jquery.scrollTo.min.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="js/elements_custom.js"></script>

</body>
</html>