<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

    <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Material Design Bootstrap</title>
  <!-- Font Awesome -->
  <!-- <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css"> -->
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/grayscale.min.css" rel="stylesheet">
</head>
    <head>
        <title>Request</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
   
      <!-- Material form contact -->
<div class="card">

    <h5 class="card-header info-color white-text text-center py-4">
       <h5><a href="home.html"> Clerance Request</a></h5>
    </h5>
<form action="../model/create.php" method="post">
    <!--Card content-->
    <div class="card-body px-lg-5 pt-0">

        <!-- Form -->
        <form class="text-center" style="color: #757575;">
          <h2>Choose Date</h2>
           <div class="md-form col-md-5" >
  <input name="Last_class_date" type="date" id="inputMDEx" class="form-control">
  <label for="inputMDEx">Choose your date</label>
</div>

          
          <h2>Reson</h2>
             <!-- Message -->
    <div class="form-group col-md-5">
        <textarea class="form-control rounded-0" id="exampleFormControlTextarea2" rows="3" placeholder="Message" name="message"></textarea>
    </div>

    <!-- Copy -->
    <div class="custom-control custom-checkbox col-md-5">
        <!--<input name="message" type="checkbox" class="custom-control-input" id="defaultContactFormCopy">-->
        <label class="custom-control-label" for="defaultContactFormCopy">Send me a copy of this message</label>

           
            <!-- Default unchecked -->
            
<div class="custom-control custom-radio  col-md-2">
  <input  type="radio" class="custom-control-input" id="defaultUnchecked" name="type" value="withdrwal">
  <label class="custom-control-label" for="defaultUnchecked">Withdrwal</label>
</div>

<!-- Default checked -->
<div class="custom-control custom-radio  col-md-2" >
  <input  type="radio" class="custom-control-input" id="defaultChecked" name="type" value="graduate" checked>
  <label class="custom-control-label" for="defaultChecked">Graduated</label>
</div>

            <!-- Subject -->
            
            
            <!-- Default checked -->


            <!-- Copy -->
          
            <!-- Send button -->
            <button class="btn btn-outline-info btn-rounded btn-block z-depth-0 my-4 waves-effect" type="submit">Send Request</button>
             <button type="button" class="btn btn-outline-secondary btn-rounded waves-effect"> <a href="home.html" >Back to Main</a></button>

        </form>
        <!-- Form -->
</form>
    </div>

    <div class="social d-flex justify-content-center">
      <a href="#" class="mx-2">
        <i class="fab fa-twitter"></i>
      </a>
      <a href="#" class="mx-2">
        <i class="fab fa-facebook-f"></i>
      </a>
      <a href="#" class="mx-2">
        <i class="fab fa-github"></i>
      </a>
    </div>

  </div>
</section>

<!-- Footer -->
<footer class="bg-black small text-center text-white-50">
  <div class="container">
    Copyright &copy; Your Website 2019
  </div>
</footer>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Plugin JavaScript -->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for this template -->
<script src="js/grayscale.min.js"></script>


  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>


    </body>
</html>
