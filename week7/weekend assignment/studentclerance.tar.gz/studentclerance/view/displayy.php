 <?php
 
 
       include_once '../controller/dbconnect.php';
       $db=new dbconnect();
       $conn=$db->connect();
       //$query="select * from request";//to fetch data
       $query="SELECT *
FROM student
INNER JOIN request
ON request.student_id=student.student_id";
       $result=mySqli_query($conn,$query);//database files
       if($result){
           echo 'error'.  mysqli_error($conn);
       }
       
       
        ?>

<!DOCTYPE html>
<!—
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
—>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <table border="1">
            <tr>
            <th> Last Date</th>
             <th> reason</th>
              <th>type</th>
              <th> Last Date</th>
             <th> reason</th>
              <th>type</th>
              <th> Last Date</th>
             <th> reason</th>
              <th>type</th>
<!--<!—               <th> Email</th>-->-->
            </tr>
            <?php while($row= mysqli_fetch_array($result)):;?>
            <tr>
                <td> <?php echo $row[0];?></td>
                 <td> <?php echo $row[1];?></td>
                 <td> <?php echo $row[2];?></td>
                   <td> <?php echo $row[3];?></td>
                 <td> <?php echo $row[4];?></td>
                 <td> <?php echo $row[5];?></td>
                   <td> <?php echo $row[6];?></td>
                 <td> <?php echo $row[7];?></td>
                 <td> <?php echo $row[8];?></td>

                  <td><button>Approve</button></td>
                  <td><button>Reject</button></td>
            </tr>
            <?php endwhile;?>
        </table>
        <script>
           var row1=document.getElementByID('mytable'),rIndex:
                   for(var i=1;i<row1.rows.length;i++){
                       row1.rows[i].oncClick=function (){
                           rIndex=this.rowIndex;
                           console.log(rIndex)
                       };
                   }
        
        </script>
    </body>
</html>