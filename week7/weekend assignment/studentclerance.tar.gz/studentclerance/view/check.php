<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
session_start();
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $_SESSION['username']="redu";
        echo $_SESSION['username'];
        ?>
        <a href="home.php">HOME</a>
        <a href="phptest.php">login</a>
    </body>
</html>
