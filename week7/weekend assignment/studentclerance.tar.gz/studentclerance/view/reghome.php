 <?php
			session_start();
 
//        include_once '../controller/dbconnect.php';
//        $db=new dbconnect();
//        $conn=$db->connect();
//        //$query="select * from request";//to fetch data
//        $query="SELECT *
// FROM student
// INNER JOIN request
// ON request.student_id=student.student_id";
//        $result=mySqli_query($conn,$query);//database files
//        if($result){
//            echo 'error'.  mysqli_error($conn);
//        }
       
       
        ?>
<html lang="en">
<head>
<title>Elements</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Elearn project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="plugins/video-js/video-js.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="styles/elements.css">
<link rel="stylesheet" type="text/css" href="styles/elements_responsive.css">
</head>
<body>
	<script>
		var dataSet = [
		["Tiger Nixon", "System Architect", "Edinburgh", "5421", "2011-04-25", "$320,800"],
		["Garrett Winters", "Accountant", "Tokyo", "8422", "2011-07-25", "$170,750"],
		["Ashton Third Cox", "Junior Technical Author", "San Francisco", "1562", "2009-01-12", "$86,000"],
		["Cedric Kelly", "Senior Javascript Developer", "Edinburgh", "6224", "2012-03-29", "$433,060"],
		["Airi", "Accountant", "Tokyo", "5407", "2008-11-28", "$162,700"],
		["Brielle Williamson Need More Space To Check It", "Integration Specialist", "New York", "4804", "2012-12-02",
		"$372,000"
		],
		["Herrod Chandler", "Sales Assistant", "San Francisco", "9608", "2012-08-06", "$137,500"],
		["Rhona Davidson", "Integration Specialist", "Tokyo", "6200", "2010-10-14", "$327,900"],
		["Colleen Hurst", "Javascript Developer", "San Francisco", "2360", "2009-09-15", "$205,500"],
		["Sonya Frost", "Software Engineer", "Edinburgh", "1667", "2008-12-13", "$103,600"],
		["Jena Gaines", "Office Manager", "London", "3814", "2008-12-19", "$90,560"],
		["Quinn Flynn", "Support Lead", "Edinburgh", "9497", "2013-03-03", "$342,000"],
		["Charde Marshall", "Regional Director", "San Francisco", "6741", "2008-10-16", "$470,600"],
		["Haley Kennedy", "Senior Marketing Designer", "London", "3597", "2012-12-18", "$313,500"],
		["Tatyana Fitzpatrick", "Regional Director", "London", "1965", "2010-03-17", "$385,750"],
		["Michael Silva", "Marketing Designer", "London", "1581", "2012-11-27", "$198,500"],
		["Paul Byrd", "Chief Financial Officer (CFO)", "New York", "3059", "2010-06-09", "$725,000"],
		["Gloria Little", "Systems Administrator", "New York", "1721", "2009-04-10", "$237,500"],
		["Bradley Fourth Fourth Greer", "Software Engineer", "London", "2558", "2012-10-13", "$132,000"],
		["Dai Rios", "Personnel Lead", "Edinburgh", "2290", "2012-09-26", "$217,500"],
		["Jenette Caldwell", "Development Lead", "New York", "1937", "2011-09-03", "$345,000"],
		["Yuri Berry", "Chief Marketing Officer (CMO)", "New York", "6154", "2009-06-25", "$675,000"],
		["Caesar Vance", "Pre-Sales Support", "New York", "8330", "2011-12-12", "$106,450"],
		["Doris Wilder", "Sales Assistant", "Sidney", "3023", "2010-09-20", "$85,600"],
		["Angelica Ramos", "Chief Executive Officer (CEO)", "London", "5797", "2009-10-09", "$1,200,000"],
		["Gavin Joyce", "Developer", "Edinburgh", "8822", "2010-12-22", "$92,575"],
		["Jennifer Chang", "Regional Director", "Singapore", "9239", "2010-11-14", "$357,650"],
		["Brenden Fifth Example Some Wagner", "Software Engineer", "San Francisco", "1314", "2011-06-07", "$206,850"],
		["Fiona Green", "Chief Operating Officer (COO)", "San Francisco", "2947", "2010-03-11", "$850,000"],
		["Shou Itou", "Regional Marketing", "Tokyo", "8899", "2011-08-14", "$163,000"],
		["Michelle House", "Integration Specialist", "Sidney", "2769", "2011-06-02", "$95,400"],
		["Suki Burks", "Developer", "London", "6832", "2009-10-22", "$114,500"],
		["Prescott Bartlett", "Technical Author", "London", "3606", "2011-05-07", "$145,000"],
		["Gavin Cortez", "Team Leader", "San Francisco", "2860", "2008-10-26", "$235,500"],
		["Martena Mccray", "Post-Sales support", "Edinburgh", "8240", "2011-03-09", "$324,050"],
		["Unity Butler", "Marketing Designer", "San Francisco", "5384", "2009-12-09", "$85,675"]
		];
		
		$(document).ready(function () {
		var table = $('#dt-select').DataTable({
		data: dataSet,
		columns: [{
		title: "Name"
		},
		{
		title: "Position"
		},
		{
		title: "Office"
		},
		{
		title: "Extn."
		},
		{
		title: "Start date"
		},
		{
		title: "Salary"
		}
		],
		
		dom: 'Bfrtip',
		select: true,
		buttons: [{
		text: 'Select all',
		action: function () {
		table.rows().select();
		}
		},
		{
		text: 'Select none',
		action: function () {
		table.rows().deselect();
		}
		}
		]
		});
		});
		
		
				</script>
<div class="super_container">

	<!-- Header -->

	<header class="header">
			
		<!-- Top Bar -->
		<div class="top_bar">
			<div class="top_bar_container">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
								<ul class="top_bar_contact_list">
									<li><div class="question">OCS</div></li>
									<li>
										<div>+251111239720</div>
									</li>
									<li>
										<div>aait@gamil.com</div>
									</li>
								</ul>
								<div class="top_bar_login ml-auto">
									<ul>
										
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>				
		</div>

		<!-- Header Content -->
		<div class="header_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_content d-flex flex-row align-items-center justify-content-start">
							<div class="logo_container">
								<a href="#">
									<div class="logo_content d-flex flex-row align-items-end justify-content-start">
                                                                            <div class="logo_img"><img src="images/download.jpg" height="80px" alt=""></div>
										
									</div>
								</a>
							</div>
							<nav class="main_nav_contaner ml-auto">
								<ul class="main_nav">
                                                                    <li><a href="newhome.html">home</a></li>
                                                                        <li><a href="reghome.php">Request Status</a></li>
									
								</ul>
								

								<div class="hamburger menu_mm">
									<i class="fa fa-bars menu_mm" aria-hidden="true"></i>
								</div>
							</nav>

						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Header Search Panel -->
		<div class="header_search_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_search_content d-flex flex-row align-items-center justify-content-end">
							<form action="#" class="header_search_form">
								<input type="search" class="search_input" placeholder="Search" required="required">
								<button class="header_search_button d-flex flex-column align-items-center justify-content-center">
									<i class="fa fa-search" aria-hidden="true"></i>
								</button>
							</form>
						</div>
					</div>
				</div>
			</div>			
		</div>			
	</header>

	<!-- Menu -->

	<div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
		<div class="menu_close_container"><div class="menu_close"><div></div><div></div></div></div>
		<div class="search">
			<form action="#" class="header_search_form menu_mm">
				<input type="search" class="search_input menu_mm" placeholder="Search" required="required">
				<button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
					<i class="fa fa-search menu_mm" aria-hidden="true"></i>
				</button>
			</form>
		</div>
		<nav class="menu_nav">
			<ul class="menu_mm">
                            <li class="menu_mm"><a href="newhome.html">Home</a></li>
				<li class="menu_mm"><a href="regihome.html">Request status</a></li>
				>
			</ul>
		</nav>
		<div class="menu_extra">
			<div class="menu_phone"><span class="menu_title">phone:</span>+251111239720</div>
			<div class="menu_social">
				<span class="menu_title">follow us</span>
				<ul>
					
					<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
				
				</ul>
			</div>
		</div>
	</div>
	
	<!-- Home -->

	<div class="home">
		<!-- Background image artist https://unsplash.com/@thepootphotographer -->
		<div class="home_background parallax_background parallax-window" data-parallax="scroll" data-image-src="images/elements.jpg" data-speed="0.8"></div>
		<div class="home_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="home_content text-center">
							<div class="home_title">Request OCS</div>
							<div class="breadcrumbs">
								<ul>
                                                                    <li><a href="newhome.html">Home</a></li>
									<li>Request</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Elements -->

	

		<!-- Milestones -->
		<div class="milestones_section">
			<div class="container">
				<div class="row">
					<div class="col">
                                            <div class="elements_title">Request Status</div><br>
                                                
                                                <div>
										<table id="dt-select" class="table table-striped table-bordered" cellspacing="0" width="100%">
											<thead>
											  <tr>
												<th>Student 
													Name 
													</th>
												<th>Phone 
													Number 
													</th>
												<th>Gender</th>
												<th>Department</th>
												<th> program </th>
												<th>Request date </th>
												<th>student ID  </th>
												<th>Last Approved by</th>
												<th>Action </th>
											  </tr>
											</thead>
											<tfoot>
											 
  
			<?php 
				  include_once '../model/element.php';


          $elements = "";
				  if ($_SESSION["officetype"] == "library") {
					$elements = getelements();
				  }else {
					$elements = getelementsreg();
				  }
				  while ($row = $elements->fetch_assoc()) {
					  echo "<tr>";

					  echo "<td>".$row["fullname"]."</td>";
					  echo "<td>".$row["phone"]."</td>";
					  echo "<td>".$row["gender"]."</td>";
					  echo "<td>".$row["program"]."</td>";
					  echo "<td>".$row["type"]."</td>";
						echo "<td>".$row["reqdate"]."</td>";
						echo "<td>".$row["student_id"]."</td>";

					  $status = getstatus($row["reqid"]);
					  $buttons = "";
					  if(empty($status["officeid"])){
						echo "<td>None yet</td>";
					  }else{
						  $val = "Accepted by ";
						  if ($status["status"] < 0) {
							  $val = "Rejected By ";
							  $buttons = "disabled";
						  }
						  if($status["status"] > 1){
							$buttons = "disabled";
						  }
					  echo "<td>".$val.$status["officename"]."</td>";
					  		
					  }

					  $accepturl = "onclick='window.location=".'"../model/request.php?type=accept&id='.$row["reqid"].'"'."'";
					  $declineurl = "onclick='window.location=".'"../model/request.php?type=decline&id='.$row["reqid"].'"'."'";
					  echo '<td><button '.$buttons." ".$accepturl.' type="button" class="btn btn-outline-success btn-rounded waves-effect">Accept</button> &nbsp; 

					  <button type="button" '.$buttons." ".$declineurl.'class="btn btn-outline-danger btn-rounded waves-effect">Reject</button></td>';



					  echo "</tr>";
				  }
                  
          ?>
											</tfoot>
										  </table>
										  </div>
					</div>
				</div>
			</div>
		</div>
		<div class="milestones">
			<!-- Background image artis https://unsplash.com/@thepootphotographer -->
			<div class="milestones_background" style="background-image:url(images/milestones.jpg)"></div>
			<div class="container">
				<div class="row milestones_container">
								
					<!-- Milestone -->
					<div class="col-lg-3 milestone_col">
						<div class="milestone text-center">
							<div class="milestone_icon"><img src="images/milestone_1.svg" alt=""></div>
							<div class="milestone_counter" data-end-value="1548">0</div>
							<div class="milestone_text">Online OCS</div>
						</div>
					</div>

					<!-- Milestone -->
					<div class="col-lg-3 milestone_col">
						<div class="milestone text-center">
							<div class="milestone_icon"><img src="images/milestone_2.svg" alt=""></div>
							<div class="milestone_counter" data-end-value="7286">0</div>
							<div class="milestone_text">Students</div>
						</div>
					</div>

					<!-- Milestone -->
					<div class="col-lg-3 milestone_col">
						<div class="milestone text-center">
							<div class="milestone_icon"><img src="images/milestone_3.svg" alt=""></div>
							<div class="milestone_counter" data-end-value="257">0</div>
							<div class="milestone_text">Office</div>
						</div>
					</div>

					<!-- Milestone -->
					<div class="col-lg-3 milestone_col">
						<div class="milestone text-center">
							<div class="milestone_icon"><img src="images/milestone_4.svg" alt=""></div>
							<div class="milestone_counter" data-end-value="39">0</div>
							<div class="milestone_text">Universty</div>
						</div>
					</div>

				</div>
			</div>
		</div>

		<!-- Loaders -->
		<div class="loaders">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="elements_title"></div>
					</div>
				</div>
				<div class="row loaders_container">
					<div class="col-lg-3 loader_col">
						<!-- Loader -->
						<div class="loader" data-perc="1.00"><span>Education</span></div>
					</div>
					<div class="col-lg-3 loader_col">
						<!-- Loader -->
						<div class="loader" data-perc="0.50"><span>background</span></div>
					</div>
					<div class="col-lg-3 loader_col">
						<!-- Loader -->
						<div class="loader" data-perc="0.75"><span>Work</span></div>
					</div>
					<div class="col-lg-3 loader_col">
						<!-- Loader -->
						<div class="loader" data-perc="0.90"><span>Inspiration</span></div>
					</div>
				</div>
			</div>
		</div>

		<!-- Icon Boxes -->
		<div class="icon_boxes">
			<div class="container">
				<div class="row">
					<div class="col">
					
					</div>
				</div>
				<div class="row icon_boxes_row">
					
					<!-- Icon Box -->
					<div class="col-lg-4 ib_col">
						<div class="icon_box">
							<div class="ib_title_container d-flex flex-row align-items-center justify-content-start">
								<div class="ib_image"><img src="images/icon_1.png" alt=""></div>
								<div class="ib_title">Social Media </div>
							</div>
							<div class="ib_text">
								<p>Online student clearance system is a process a student needs to complete before they leave university. .</p>
							</div>
						</div>
					</div>

					<!-- Icon Box -->
					<div class="col-lg-4 ib_col">
						<div class="icon_box">
							<div class="ib_title_container d-flex flex-row align-items-center justify-content-start">
								<div class="ib_image"><img src="images/icon_2.png" alt=""></div>
								<div class="ib_title">The Best Education</div>
							</div>
							<div class="ib_text">
								<pOnline student clearance system is a process a student needs to complete before they leave university. .</p>
							</div>
						</div>
					</div>

					<!-- Icon Box -->
					<div class="col-lg-4 ib_col">
						<div class="icon_box">
							<div class="ib_title_container d-flex flex-row align-items-center justify-content-start">
								<div class="ib_image"><img src="images/icon_3.png" alt=""></div>
								<div class="ib_title">Certification</div>
							</div>
							<div class="ib_text">
								<p>Online student clearance system is a process a student needs to complete before they leave university. .</p>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>

	</div>

	<!-- Footer -->

	<footer class="footer">
		<div class="container">
			<div class="row">

				<!-- About -->
				<div class="col-lg-3 footer_col">
					<div class="footer_about">
						<div class="logo_container">
							<a href="#">
								<div class="logo_content d-flex flex-row align-items-end justify-content-start">
									<div class="logo_img"><img src="images/logo.png" alt=""></div>
									<div class="logo_text">OCS</div>
								</div>
							</a>
						</div>
						<div class="footer_about_text">
							<p>Online student clearance system is a process a student needs to complete before they leave university. .</p>
						</div>
						<div class="footer_social">
							<ul>
								
							</ul>
						</div>
						<div class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | AAit <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://www.aait.edu.et" target="_blank">AAit</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
					</div>
				</div>

				<div class="col-lg-3 footer_col">
					<div class="footer_links">
						<div class="footer_title"></div>
						<ul class="footer_list">
							
						</ul>
					</div>
				</div>

				<div class="col-lg-3 footer_col">
					<div class="footer_links">
						<div class="footer_title"></div>
						<ul class="footer_list">
							
						</ul>
					</div>
				</div>

				<div class="col-lg-3 footer_col">
					<div class="footer_contact">
						<div class="footer_title">Contact Us</div>
						<div class="footer_contact_info">
							<div class="footer_contact_item">
								<div class="footer_contact_title">Address:</div>
								<div class="footer_contact_line">5 kilo </div>
							</div>
							<div class="footer_contact_item">
								<div class="footer_contact_title">Phone:</div>
								<div class="footer_contact_line">+251111239720</div>
							</div>
							<div class="footer_contact_item">
								<div class="footer_contact_title">Email:</div>
								<div class="footer_contact_line">aait@gmail.com</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/progressbar/progressbar.min.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="js/elements.js"></script>
</body>
</html>
